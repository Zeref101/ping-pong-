def random_color():
    color = random.choice(lst)
    return color
